package com.example.audio

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class WaveformSpectrogramHelperTest {

    @Test
    fun testGenerateFallbackAmplitudes() {
        val count = 40
        val amplitudes = WaveformSpectrogramHelper.generateFallbackAmplitudes(count, 0.75f)
        assertEquals(count, amplitudes.size)
        amplitudes.forEach { amp ->
            assertTrue("Amplitude $amp should be >= 0.0", amp >= 0.0f)
            assertTrue("Amplitude $amp should be <= 1.0", amp <= 1.0f)
        }
    }

    @Test
    fun testExtractAmplitudesNonExistentFile() = kotlinx.coroutines.runBlocking {
        val nonExistent = File("/path/does/not/exist/song.mp3")
        val amplitudes = WaveformSpectrogramHelper.extractAmplitudes(nonExistent, 30)
        assertEquals(30, amplitudes.size)
    }

    @Test
    fun testComputeDiff() {
        val orig = listOf(0.4f, 0.5f, 0.6f, 0.7f)
        val mod = listOf(0.5f, 0.6f, 0.7f, 0.8f)
        val diff = WaveformSpectrogramHelper.computeDiff(orig, mod)

        assertTrue(diff.isReady)
        assertTrue(diff.variancePercentage > 0f)
        assertEquals(orig, diff.originalAmplitudes)
        assertEquals(mod, diff.modifiedAmplitudes)
    }

    @Test
    fun testGetFrequencyBands() {
        val bands = WaveformSpectrogramHelper.getFrequencyBands(0.5f, true)
        assertEquals(5, bands.size)
        assertNotNull(bands.find { it.name == "Sub-Bass" })
        assertNotNull(bands.find { it.name == "Vocal Clarity" })
        assertNotNull(bands.find { it.name == "Presence" })
        assertNotNull(bands.find { it.name == "Crystal Air" })
        assertNotNull(bands.find { it.name == "Safe Shield" })

        bands.forEach { band ->
            assertTrue(band.originalLevel in 0.0f..1.0f)
            assertTrue(band.modifiedLevel in 0.0f..1.0f)
            assertTrue(band.deltaLabel.isNotEmpty())
        }
    }

    @Test
    fun testFormatDuration() {
        assertEquals("--:--", StorageHelper.formatDuration(0))
        assertEquals("01:30", StorageHelper.formatDuration(90_000))
        assertEquals("03:45", StorageHelper.formatDuration(225_000))
    }

    @Test
    fun testFormatFileSize() {
        assertEquals("0 B", StorageHelper.formatFileSize(0))
        assertTrue(StorageHelper.formatFileSize(1024).contains("KB"))
        assertTrue(StorageHelper.formatFileSize(1024 * 1024 * 5).contains("MB"))
    }
}
