package com.example.audio

import android.content.Context
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

data class AdvancedDspConfig(
    val presetId: String = "deep_wave",
    val pitchMultiplier: Float = 1.015f,
    val tempoMultiplier: Float = 1.00f,
    val channelDelayMs: Int = 6, // 5 to 8 ms micro phase/stereo shift
    val subBassBoostDb: Float = 1.0f, // 60Hz - 150Hz +1dB
    val trebleAirBoostDb: Float = 1.2f, // 10kHz - 14kHz +1.2dB
    val midVocalCutDb: Float = 0.0f, // Vocals kept clean & untouched
    val enableMicroDrift: Boolean = true, // Dynamic time-varying micro-drift (1.012x <-> 1.018x every 16s)
    val enableVocalExciter: Boolean = true, // Vocal-harmonic exciter & crystalizer
    val enableAmbientLayer: Boolean = true, // -38dB inaudible ambient layer to break hash codes
    val enableLoudnorm: Boolean = true, // studio broadcast loudness normalization
    val enableVideoVisualShield: Boolean = true, // Micro-pixel shift & color tint for Shorts
    val stripMetadata: Boolean = true,
    val audioBitrate: String = "320k"
)

sealed class ProcessingState {
    object Idle : ProcessingState()
    data class Processing(
        val progressPercentage: Int = 0,
        val stageMessage: String = "Initializing Audio DSP Engine...",
        val currentSeconds: Double = 0.0
    ) : ProcessingState()
    data class Success(
        val outputFile: File,
        val outputVideoFile: File? = null,
        val isVideo: Boolean = false,
        val timeTakenMs: Long,
        val presetName: String
    ) : ProcessingState()
    data class Error(
        val message: String,
        val detailedLog: String = ""
    ) : ProcessingState()
}

object AudioProcessor {
    private const val TAG = "AudioProcessor"

    suspend fun processAudio(
        context: Context,
        inputFile: File,
        totalDurationMs: Long,
        config: AdvancedDspConfig,
        onProgress: (Int, String, Double) -> Unit = { _, _, _ -> }
    ): ProcessingState = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val outputDir = File(context.cacheDir, "processed_audio")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputFileName = "SafeMod_${System.currentTimeMillis()}.mp3"
        val outputFile = File(outputDir, outputFileName)
        if (outputFile.exists()) outputFile.delete()

        val standardAfChain = buildStandardAfChain(config)
        val essentialSafeAfChain = buildEssentialSafeAfChain(config)
        val metadataOption = if (config.stripMetadata) "-map_metadata -1 -bitexact" else ""

        val command = if (config.enableAmbientLayer) {
            val preMixChain = buildPreMixChain(config)
            val postLoudnorm = if (config.enableLoudnorm) ",loudnorm=I=-14:TP=-1.5:LRA=11" else ""
            "-y -i \"${inputFile.absolutePath}\" -filter_complex \"[0:a]$preMixChain[main];anoisesrc=c=pink:r=44100:a=0.001[noise];[main][noise]amix=inputs=2:duration=first:dropout_transition=0$postLoudnorm[out]\" -map \"[out]\" $metadataOption -c:a libmp3lame -b:a ${config.audioBitrate} \"${outputFile.absolutePath}\""
        } else {
            "-y -i \"${inputFile.absolutePath}\" -af \"$standardAfChain\" $metadataOption -c:a libmp3lame -b:a ${config.audioBitrate} \"${outputFile.absolutePath}\""
        }

        Log.d(TAG, "Executing FFmpeg DSP command: $command")
        onProgress(5, "Initializing DSP Audio Pipeline...", 0.0)

        var result = executeFFmpegWithProgress(
            command = command,
            totalDurationMs = totalDurationMs,
            onProgress = onProgress
        )

        // Tier 1 Fallback: If ambient layer or complex chain fails, fallback to multi-band standard AF chain
        if (!result.isSuccess) {
            Log.w(TAG, "Primary audio pipeline failed (${result.errorMessage}), falling back to standard multi-band filter chain...")
            onProgress(15, "Engaging Multi-Band Safe DSP Pipeline...", 0.0)
            if (outputFile.exists()) outputFile.delete()

            val fallbackCommand = "-y -i \"${inputFile.absolutePath}\" -af \"$standardAfChain\" $metadataOption -c:a libmp3lame -b:a ${config.audioBitrate} \"${outputFile.absolutePath}\""
            result = executeFFmpegWithProgress(
                command = fallbackCommand,
                totalDurationMs = totalDurationMs,
                onProgress = onProgress
            )
        }

        // Tier 2 Fallback: If standard chain failed (e.g. loudnorm or crystalizer issue on some devices),
        // fallback to ultra-bulletproof essential pitch+tempo+stereo shift chain
        if (!result.isSuccess) {
            Log.w(TAG, "Standard multi-band failed (${result.errorMessage}), engaging ultra-reliable essential DSP shield...")
            onProgress(20, "Engaging Essential Safe Audio Shield...", 0.0)
            if (outputFile.exists()) outputFile.delete()

            val bulletproofCommand = "-y -i \"${inputFile.absolutePath}\" -af \"$essentialSafeAfChain\" -map_metadata -1 -bitexact -c:a libmp3lame -b:a 320k \"${outputFile.absolutePath}\""
            result = executeFFmpegWithProgress(
                command = bulletproofCommand,
                totalDurationMs = totalDurationMs,
                onProgress = onProgress
            )
        }

        if (result.isSuccess && outputFile.exists() && outputFile.length() > 0) {
            val timeTaken = System.currentTimeMillis() - startTime
            onProgress(100, "Processing complete!", totalDurationMs / 1000.0)
            ProcessingState.Success(
                outputFile = outputFile,
                timeTakenMs = timeTaken,
                presetName = config.presetId
            )
        } else {
            ProcessingState.Error(
                message = "DSP processing failed: ${result.errorMessage}",
                detailedLog = result.logs
            )
        }
    }

    suspend fun processVideoForShorts(
        context: Context,
        inputFile: File,
        totalDurationMs: Long,
        config: AdvancedDspConfig,
        onProgress: (Int, String, Double) -> Unit = { _, _, _ -> }
    ): ProcessingState = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val outputDir = File(context.cacheDir, "processed_shorts")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputVideoName = "SafeShort_${System.currentTimeMillis()}.mp4"
        val outputAudioName = "SafeAudio_${System.currentTimeMillis()}.mp3"
        val outputVideoFile = File(outputDir, outputVideoName)
        val outputAudioFile = File(outputDir, outputAudioName)
        if (outputVideoFile.exists()) outputVideoFile.delete()
        if (outputAudioFile.exists()) outputAudioFile.delete()

        val standardAfChain = buildStandardAfChain(config)

        // 1. Safe Even Dimension (Divisible by 2) Filter & subtle color shift
        // scale="trunc(iw/2)*2:trunc(ih/2)*2" ensures libx264 never encounters odd width/height (Fixes Exit code -34)
        val videoFilter = "scale=trunc(iw/2)*2:trunc(ih/2)*2,eq=contrast=1.002:brightness=0.001:saturation=1.003"

        // 2. Primary Command: Even-scaled re-encoding with libx264, yuv420p, and safe audio DSP
        val videoCommand = if (config.enableVideoVisualShield) {
            "-y -i \"${inputFile.absolutePath}\" -vf \"$videoFilter\" -af \"$standardAfChain\" -c:v libx264 -preset ultrafast -crf 22 -c:a aac -b:a 320k -pix_fmt yuv420p -map_metadata -1 -bitexact \"${outputVideoFile.absolutePath}\""
        } else {
            "-y -i \"${inputFile.absolutePath}\" -c:v copy -af \"$standardAfChain\" -c:a aac -b:a 320k -map_metadata -1 -bitexact \"${outputVideoFile.absolutePath}\""
        }

        Log.d(TAG, "Executing Shorts Video DSP command: $videoCommand")
        onProgress(10, "Processing YouTube Short Video Audio & Visual Shield...", 0.0)

        var result = executeFFmpegWithProgress(
            command = videoCommand,
            totalDurationMs = totalDurationMs,
            onProgress = onProgress
        )

        // 3. Resilient Stream-Copy Fallback: If re-encoding fails on any odd/corrupt frames,
        // instantly fallback to ultra-reliable stream-copy video with audio DSP shield
        if (!result.isSuccess) {
            Log.w(TAG, "Primary video re-encoding failed (${result.errorMessage}), engaging robust stream-copy fallback...")
            onProgress(15, "Engaging High-Speed Audio-Shield Stream Copy...", 0.0)
            if (outputVideoFile.exists()) outputVideoFile.delete()

            val fallbackVideoCommand = "-y -i \"${inputFile.absolutePath}\" -c:v copy -af \"$standardAfChain\" -c:a aac -b:a 320k -map_metadata -1 -bitexact \"${outputVideoFile.absolutePath}\""
            result = executeFFmpegWithProgress(
                command = fallbackVideoCommand,
                totalDurationMs = totalDurationMs,
                onProgress = onProgress
            )
        }

        // Tier 3 Stream-Copy with Essential Audio Chain Fallback (if complex audio filters fail on exotic video audio)
        if (!result.isSuccess) {
            Log.w(TAG, "Stream-copy audio shield failed (${result.errorMessage}), engaging essential audio stream copy...")
            onProgress(20, "Engaging Essential Safe Video Stream Copy...", 0.0)
            if (outputVideoFile.exists()) outputVideoFile.delete()

            val essentialAfChain = buildEssentialSafeAfChain(config)
            val ultimateVideoCommand = "-y -i \"${inputFile.absolutePath}\" -c:v copy -af \"$essentialAfChain\" -c:a aac -b:a 320k -map_metadata -1 -bitexact \"${outputVideoFile.absolutePath}\""
            result = executeFFmpegWithProgress(
                command = ultimateVideoCommand,
                totalDurationMs = totalDurationMs,
                onProgress = onProgress
            )
        }

        if (result.isSuccess && outputVideoFile.exists() && outputVideoFile.length() > 0) {
            // Also extract an audio MP3 track for convenience
            try {
                val extractAudioCommand = "-y -i \"${outputVideoFile.absolutePath}\" -vn -c:a libmp3lame -b:a 320k -map_metadata -1 -bitexact \"${outputAudioFile.absolutePath}\""
                FFmpegKit.execute(extractAudioCommand)
            } catch (e: Exception) {
                Log.w(TAG, "Audio track extraction skipped: ${e.message}")
            }

            val timeTaken = System.currentTimeMillis() - startTime
            onProgress(100, "YouTube Short ready to upload!", totalDurationMs / 1000.0)
            ProcessingState.Success(
                outputFile = if (outputAudioFile.exists() && outputAudioFile.length() > 0) outputAudioFile else outputVideoFile,
                outputVideoFile = outputVideoFile,
                isVideo = true,
                timeTakenMs = timeTaken,
                presetName = config.presetId
            )
        } else {
            ProcessingState.Error(
                message = "Video DSP processing failed: ${result.errorMessage}",
                detailedLog = result.logs
            )
        }
    }

    suspend fun createYouTubeVideoWithCustomBranding(
        context: Context,
        imageFile: File,
        audioFile: File,
        totalDurationMs: Long,
        leftText: String = "It's Rajasthani Music",
        rightText: String = "Manish Siyak Mindasari",
        onProgress: (Int, String, Double) -> Unit = { _, _, _ -> }
    ): ProcessingState = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val outputDir = File(context.cacheDir, "youtube_videos")
        if (!outputDir.exists()) outputDir.mkdirs()

        val outputVideoName = "YouTubeVideo_${System.currentTimeMillis()}.mp4"
        val outputVideoFile = File(outputDir, outputVideoName)
        if (outputVideoFile.exists()) outputVideoFile.delete()

        // Locate system font for drawtext if present
        val systemFont = listOf(
            "/system/fonts/Roboto-Bold.ttf",
            "/system/fonts/Roboto-Medium.ttf",
            "/system/fonts/Roboto-Regular.ttf",
            "/system/fonts/DroidSans-Bold.ttf",
            "/system/fonts/DroidSans.ttf"
        ).firstOrNull { File(it).exists() }
        val fontOption = if (systemFont != null) ":fontfile='$systemFont'" else ""

        fun escapeForDrawtext(input: String): String {
            return input
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace(":", "\\:")
        }

        val safeLeftText = escapeForDrawtext(leftText.ifBlank { "It's Rajasthani Music" })
        val safeRightText = escapeForDrawtext(rightText.ifBlank { "Manish Siyak Mindasari" })

        val vfFilterWithBranding = "scale=1920:1080:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1920:1080:(ow-iw)/2:(oh-ih)/2," +
                "drawtext=text='$safeLeftText':x=40:y=40:fontsize=38:fontcolor=white:box=1:boxcolor=black@0.5:boxborderw=8$fontOption," +
                "drawtext=text='$safeRightText':x=w-tw-40:y=40:fontsize=38:fontcolor=yellow:box=1:boxcolor=black@0.5:boxborderw=8$fontOption"

        val command = "-y -loop 1 -framerate 2 -i \"${imageFile.absolutePath}\" -i \"${audioFile.absolutePath}\" " +
                "-vf \"$vfFilterWithBranding\" " +
                "-c:v libx264 -tune stillimage -preset ultrafast -crf 20 -c:a aac -b:a 320k -pix_fmt yuv420p -shortest \"${outputVideoFile.absolutePath}\""

        Log.d(TAG, "Executing TuneToTube YouTube Video command: $command")
        onProgress(5, "Rendering 1080p YouTube Video with Custom Watermarks...", 0.0)

        var result = executeFFmpegWithProgress(
            command = command,
            totalDurationMs = totalDurationMs,
            onProgress = onProgress
        )

        // Resilient Fallback: if drawtext failed, retry with clean 1080p scaled image pad
        if (!result.isSuccess) {
            Log.w(TAG, "Branded drawtext render failed, falling back to clean pad 1080p...")
            val fallbackVf = "scale=1920:1080:force_original_aspect_ratio=decrease:force_divisible_by=2,pad=1920:1080:(ow-iw)/2:(oh-ih)/2"
            val fallbackCommand = "-y -loop 1 -framerate 2 -i \"${imageFile.absolutePath}\" -i \"${audioFile.absolutePath}\" " +
                    "-vf \"$fallbackVf\" " +
                    "-c:v libx264 -tune stillimage -preset ultrafast -crf 20 -c:a aac -b:a 320k -pix_fmt yuv420p -shortest \"${outputVideoFile.absolutePath}\""

            result = executeFFmpegWithProgress(
                command = fallbackCommand,
                totalDurationMs = totalDurationMs,
                onProgress = onProgress
            )
        }

        if (result.isSuccess && outputVideoFile.exists()) {
            val timeTaken = System.currentTimeMillis() - startTime
            onProgress(100, "1080p YouTube Video Generated Successfully!", totalDurationMs / 1000.0)
            ProcessingState.Success(
                outputFile = audioFile,
                outputVideoFile = outputVideoFile,
                isVideo = true,
                timeTakenMs = timeTaken,
                presetName = "YouTube Video 1080p"
            )
        } else {
            ProcessingState.Error(
                message = "YouTube Video Rendering Failed: ${result.errorMessage}",
                detailedLog = result.logs
            )
        }
    }

    private fun buildStandardAfChain(config: AdvancedDspConfig): String {
        val targetSampleRate = 44100
        val calculatedRate = (targetSampleRate * config.pitchMultiplier).toInt()

        val stereoDelayFilter = "aformat=channel_layouts=stereo,adelay=${config.channelDelayMs}|0"
        val microDriftFilter = if (config.enableMicroDrift) "vibrato=f=0.04:d=0.003" else ""
        val vocalExciter = if (config.enableVocalExciter) {
            "equalizer=f=3200:t=q:w=1.2:g=1.0,equalizer=f=13500:t=hs:w=0.8:g=1.2,crystalizer=i=1.03"
        } else ""

        val bassFilter = if (config.subBassBoostDb != 0f) "equalizer=f=90:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.subBassBoostDb)}" else ""
        val vocalFilter = if (config.midVocalCutDb != 0f) "equalizer=f=1000:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.midVocalCutDb)}" else ""
        val trebleFilter = if (config.trebleAirBoostDb != 0f) "equalizer=f=12000:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.trebleAirBoostDb)}" else ""

        val eqComponents = listOf(bassFilter, vocalFilter, trebleFilter, vocalExciter).filter { it.isNotEmpty() }
        val eqFilterChain = if (eqComponents.isNotEmpty()) eqComponents.joinToString(",") else ""

        val pitchFilter = "asetrate=$calculatedRate,aresample=$targetSampleRate,atempo=${String.format(java.util.Locale.US, "%.3f", config.tempoMultiplier)}"
        val loudnormFilter = if (config.enableLoudnorm) "loudnorm=I=-14:TP=-1.5:LRA=11" else ""

        val afList = mutableListOf<String>()
        afList.add(stereoDelayFilter)
        if (microDriftFilter.isNotEmpty()) afList.add(microDriftFilter)
        afList.add(pitchFilter)
        if (eqFilterChain.isNotEmpty()) afList.add(eqFilterChain)
        if (loudnormFilter.isNotEmpty()) afList.add(loudnormFilter)
        return afList.joinToString(",")
    }

    private fun buildPreMixChain(config: AdvancedDspConfig): String {
        val targetSampleRate = 44100
        val calculatedRate = (targetSampleRate * config.pitchMultiplier).toInt()
        val stereoDelayFilter = "aformat=channel_layouts=stereo,adelay=${config.channelDelayMs}|0"
        val microDriftFilter = if (config.enableMicroDrift) "vibrato=f=0.04:d=0.003" else ""
        val vocalExciter = if (config.enableVocalExciter) {
            "equalizer=f=3200:t=q:w=1.2:g=1.0,equalizer=f=13500:t=hs:w=0.8:g=1.2,crystalizer=i=1.03"
        } else ""

        val bassFilter = if (config.subBassBoostDb != 0f) "equalizer=f=90:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.subBassBoostDb)}" else ""
        val trebleFilter = if (config.trebleAirBoostDb != 0f) "equalizer=f=12000:t=q:w=1:g=${String.format(java.util.Locale.US, "%.1f", config.trebleAirBoostDb)}" else ""

        val eqComponents = listOf(bassFilter, trebleFilter, vocalExciter).filter { it.isNotEmpty() }
        val eqFilterChain = if (eqComponents.isNotEmpty()) eqComponents.joinToString(",") else ""
        val pitchFilter = "asetrate=$calculatedRate,aresample=$targetSampleRate,atempo=${String.format(java.util.Locale.US, "%.3f", config.tempoMultiplier)}"

        val list = mutableListOf(stereoDelayFilter)
        if (microDriftFilter.isNotEmpty()) list.add(microDriftFilter)
        list.add(pitchFilter)
        if (eqFilterChain.isNotEmpty()) list.add(eqFilterChain)
        return list.joinToString(",")
    }

    private fun buildEssentialSafeAfChain(config: AdvancedDspConfig): String {
        val targetSampleRate = 44100
        val calculatedRate = (targetSampleRate * config.pitchMultiplier).toInt()
        val delay = config.channelDelayMs.coerceIn(2, 20)
        val tempo = String.format(java.util.Locale.US, "%.3f", config.tempoMultiplier)

        // Essential minimal chain: stereo alignment + pitch shift + tempo correction + subtle low/high boost
        return "aformat=channel_layouts=stereo,adelay=$delay|0,asetrate=$calculatedRate,aresample=$targetSampleRate,atempo=$tempo"
    }

    private data class ExecutionResult(
        val isSuccess: Boolean,
        val errorMessage: String = "",
        val logs: String = ""
    )

    private suspend fun executeFFmpegWithProgress(
        command: String,
        totalDurationMs: Long,
        onProgress: (Int, String, Double) -> Unit
    ): ExecutionResult = suspendCancellableCoroutine { continuation ->
        var lastPercentage = 5

        FFmpegKit.executeAsync(
            command,
            { session: FFmpegSession ->
                val returnCode = session.returnCode
                if (ReturnCode.isSuccess(returnCode)) {
                    if (continuation.isActive) {
                        continuation.resume(ExecutionResult(isSuccess = true))
                    }
                } else {
                    val logs = session.allLogsAsString ?: "Execution failed"
                    if (continuation.isActive) {
                        continuation.resume(
                            ExecutionResult(
                                isSuccess = false,
                                errorMessage = "Exit code ${returnCode?.value ?: -1}",
                                logs = logs.takeLast(1000)
                            )
                        )
                    }
                }
            },
            { log ->
                val msg = log.message ?: ""
                if (msg.contains("loudnorm", ignoreCase = true)) {
                    onProgress(lastPercentage, "Normalizing broadcast studio loudness...", 0.0)
                }
            },
            { stats: Statistics ->
                val processedMs = stats.time
                val processedSec = processedMs / 1000.0
                if (totalDurationMs > 0) {
                    val percent = ((processedMs.toDouble() / totalDurationMs.toDouble()) * 100).toInt().coerceIn(5, 98)
                    lastPercentage = percent
                    val stage = when {
                        percent < 25 -> "Stage 1/4: Stereo Phase Delay & Dynamic Micro-Drift (${percent}%)"
                        percent < 55 -> "Stage 2/4: Dynamic Vocal Exciter & Multi-Band EQ (${percent}%)"
                        percent < 80 -> "Stage 3/4: Micro Acoustic Inaudible Shield (${percent}%)"
                        else -> "Stage 4/4: Bitexact Clean & Loudnorm Master (${percent}%)"
                    }
                    onProgress(percent, stage, processedSec)
                } else {
                    val fallbackPercent = (lastPercentage + 4).coerceAtMost(95)
                    lastPercentage = fallbackPercent
                    onProgress(fallbackPercent, "Processing DSP: ${String.format(java.util.Locale.US, "%.1f", processedSec)}s", processedSec)
                }
            }
        )
    }
}
