package com.example

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioTrackType
import com.example.audio.PlayerState
import com.example.audio.WaveformDiffData
import com.example.audio.WaveformSpectrogramHelper
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.CyanSecondary
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.StudioCardBg
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun SmartSpectrogramWaveformDiff(
    waveformDiff: WaveformDiffData,
    playerState: PlayerState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "spectrogramShimmer")
    val shimmerPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200), RepeatMode.Restart),
        label = "shimmerFloat"
    )

    val progressFactor = if (playerState.durationMs > 0) {
        (playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    val frequencyBands = remember(progressFactor, playerState.isPlaying) {
        WaveformSpectrogramHelper.getFrequencyBands(progressFactor, playerState.isPlaying)
    }

    val variance = if (waveformDiff.variancePercentage > 0f) waveformDiff.variancePercentage else 17.4f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(StudioDarkBg)
            .border(1.dp, CyanPrimary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(14.dp)
            .testTag("spectrogram_waveform_diff")
    ) {
        // Header with Live Waveform Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = CyanPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "स्मार्ट स्पेक्ट्रोग्राम और वेवफ़ॉर्म तुलना",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(EmeraldTertiary.copy(alpha = 0.2f))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "DIFF: ${String.format(Locale.US, "%.1f", variance)}%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = EmeraldTertiary
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "नीचे ओरिजिनल और सेफ वेवफ़ॉर्म का अंतर देखें (पिच, फेज़ व स्पेक्ट्रम मॉड्युलेटेड):",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
            fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Dual Waveform Canvas
        val originalAmps = remember(waveformDiff) {
            if (waveformDiff.originalAmplitudes.isNotEmpty()) {
                waveformDiff.originalAmplitudes
            } else {
                WaveformSpectrogramHelper.generateFallbackAmplitudes(54, 0.65f)
            }
        }

        val modifiedAmps = remember(waveformDiff) {
            if (waveformDiff.modifiedAmplitudes.isNotEmpty()) {
                waveformDiff.modifiedAmplitudes
            } else {
                WaveformSpectrogramHelper.generateFallbackAmplitudes(54, 0.85f)
            }
        }

        val isModActive = playerState.currentTrack == AudioTrackType.MODIFIED

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(84.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF090D14))
                .border(1.dp, StudioSurfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f
            val count = originalAmps.size.coerceAtMost(modifiedAmps.size).coerceAtLeast(1)
            val barStep = width / count.toFloat()
            val barWidth = (barStep * 0.65f).coerceAtLeast(2f)

            // Draw Original Track Waveform (Soft Cyan / Slate background trace)
            for (i in 0 until count) {
                val x = i * barStep + (barStep - barWidth) / 2f
                val origAmp = originalAmps[i].coerceIn(0.1f, 0.95f)
                val barH = origAmp * (centerY - 4f)
                drawRoundRect(
                    color = if (!isModActive) CyanPrimary.copy(alpha = 0.9f) else Color(0xFF38BDF8).copy(alpha = 0.35f),
                    topLeft = Offset(x, centerY - barH),
                    size = Size(barWidth, barH * 2f),
                    cornerRadius = CornerRadius(2f, 2f)
                )
            }

            // Draw Modified Safe Track Waveform (Vibrant Emerald & Amber overlay)
            for (i in 0 until count) {
                val x = i * barStep + (barStep - barWidth) / 2f
                val modAmp = modifiedAmps[i].coerceIn(0.12f, 1.0f)
                val barH = modAmp * (centerY - 4f)
                val highlightColor = if (isModActive) EmeraldTertiary else Color(0xFF10B981).copy(alpha = 0.4f)
                drawRoundRect(
                    color = highlightColor,
                    topLeft = Offset(x + 1f, centerY - barH),
                    size = Size((barWidth * 0.75f).coerceAtLeast(1.5f), barH * 2f),
                    cornerRadius = CornerRadius(2f, 2f)
                )
            }

            // Centerline Axis
            drawLine(
                color = Color.White.copy(alpha = 0.12f),
                start = Offset(0f, centerY),
                end = Offset(width, centerY),
                strokeWidth = 1f
            )

            // Dynamic Playhead Scrubber line
            val playheadX = (width * progressFactor).coerceIn(0f, width)
            drawLine(
                color = if (isModActive) EmeraldTertiary else CyanPrimary,
                start = Offset(playheadX, 0f),
                end = Offset(playheadX, height),
                strokeWidth = 2.5f
            )

            // Glowing cursor at top and bottom of playhead
            drawCircle(
                color = if (isModActive) EmeraldTertiary else CyanPrimary,
                radius = 4.5f,
                center = Offset(playheadX, 4f)
            )
            drawCircle(
                color = if (isModActive) EmeraldTertiary else CyanPrimary,
                radius = 4.5f,
                center = Offset(playheadX, height - 4f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Legend: Original vs Safe Mod
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF38BDF8))
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "ओरिजिनल (Original)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    fontSize = 10.sp
                )

                Spacer(modifier = Modifier.width(14.dp))

                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(EmeraldTertiary)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "सेफ ट्रैक (Modulated Safe)",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldTertiary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 10.sp
                )
            }

            Text(
                text = if (isModActive) "🛡️ सेफ प्लेबैक" else "🎵 ओरिजिनल प्लेबैक",
                style = MaterialTheme.typography.labelSmall,
                color = if (isModActive) EmeraldTertiary else CyanPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Real-Time Spectrogram Multi-Band EQ Meters
        Text(
            text = "फ़्रीक्वेंसी बैंड विश्लेषण (Frequency Spectrum Bands):",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = TextSecondary,
            fontSize = 11.sp
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            frequencyBands.forEach { band ->
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF0D131F))
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Reactive EQ Meter Bar
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                    ) {
                        val w = size.width
                        val h = size.height
                        val barW = (w * 0.38f).coerceAtLeast(3f)

                        // Original band level
                        val origH = (band.originalLevel * h).coerceIn(4f, h)
                        drawRoundRect(
                            color = Color(0xFF38BDF8).copy(alpha = 0.4f),
                            topLeft = Offset(w * 0.12f, h - origH),
                            size = Size(barW, origH),
                            cornerRadius = CornerRadius(2f, 2f)
                        )

                        // Mod safe band level
                        val modH = (band.modifiedLevel * h).coerceIn(4f, h)
                        drawRoundRect(
                            color = EmeraldTertiary,
                            topLeft = Offset(w * 0.52f, h - modH),
                            size = Size(barW, modH),
                            cornerRadius = CornerRadius(2f, 2f)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = band.name,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = band.deltaLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 8.sp,
                        color = CyanSecondary,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Digital Hash Shield Confirmation Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "✓ स्थिर माइक्रो-पिच (1.015x)",
                fontSize = 9.sp,
                color = CyanSecondary
            )
            Text(
                text = "✓ 6ms फेज़ डिले",
                fontSize = 9.sp,
                color = CyanSecondary
            )
            Text(
                text = "✓ सॉफ्ट हाई-शेल्फ",
                fontSize = 9.sp,
                color = CyanSecondary
            )
            Text(
                text = "✓ -60dB शील्ड (शून्य शोर)",
                fontSize = 9.sp,
                color = EmeraldTertiary,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
